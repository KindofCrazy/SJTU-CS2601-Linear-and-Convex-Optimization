import numpy as np
import gd
import utils


gamma = # set the value of gamma by yourself here
Q = np.diag([1, gamma])

def f(x):
	return 0.5 * x@Q@x

def fp(x):
	return Q@x 

def f_2d(x1, x2):
	return 0.5 * x1**2 + 0.5 * gamma * x2**2

x0 = np.array([1.0, 1.0])
stepsize = # set step size by yourself here

x_traces = gd.gd_const_ss(fp, x0, stepsize=stepsize)

print('number of iterations:', len(x_traces)-1)

utils.plot_traces_2d(f_2d, x_traces, '../figures/gd_traces_gamma%s_ss%s.pdf' % (gamma,stepsize))
utils.plot(f, x_traces, '../figures/gd_f_gamma%s_ss%s.pdf' % (gamma, stepsize))